package com.example.khale.mlabes.tabs;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

import com.example.khale.mlabes.R;
import com.example.khale.mlabes.database.table.DatabaseHelper;
import com.example.khale.mlabes.database.table.Expenses;

import java.util.List;

public class Tab1 extends AppCompatActivity {

    DatabaseHelper mydb;
    EditText mony_out;
    String monyset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab1);

        mydb= new DatabaseHelper(this);
        mony_out=findViewById(R.id.all_mony_out);

        monyset=String.valueOf(getAllPayed());

        setmonyouting();

    }
    public void setmonyouting(){
        mony_out.setText(monyset);
    }

    public int getAllPayed(){
        int price_integer=0;

        List<String> allprices=mydb.getAllPrices(Expenses.TABLE_NAME);

        for (int i=0;i < allprices.size();i++){

            price_integer+=Integer.parseInt(allprices.get(i));
        }

        return price_integer;
    }
}
