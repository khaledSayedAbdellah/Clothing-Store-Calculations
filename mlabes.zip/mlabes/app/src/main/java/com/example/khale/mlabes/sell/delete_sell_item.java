package com.example.khale.mlabes.sell;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.khale.mlabes.R;

public class delete_sell_item extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_sell_item);
    }
}
