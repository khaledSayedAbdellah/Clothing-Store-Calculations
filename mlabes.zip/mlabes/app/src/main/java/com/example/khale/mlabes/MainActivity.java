package com.example.khale.mlabes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.example.khale.mlabes.Expenses.add_Expenses;
import com.example.khale.mlabes.database.table.DatabaseHelper;
import com.example.khale.mlabes.sell.sell_select;
import com.example.khale.mlabes.stock.stock_select;
import com.example.khale.mlabes.tabs.Tab1;
import com.example.khale.mlabes.tabs.Tab2;
import com.example.khale.mlabes.tabs.Tab3;
import com.example.khale.mlabes.tabs.Tab4;

public class MainActivity extends AppCompatActivity {


    public static DatabaseHelper mydb;
    /**
     * The {@link android.support.v4.view.PagerAdapter} that will provide
     * fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * {@link android.support.v4.app.FragmentStatePagerAdapter}.
     */

    /**
     * The {@link ViewPager} that will host the section contents.
     */
    private ViewPager mViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings_stock) {
            return true;

        }

        return super.onOptionsItemSelected(item);
    }
    //---------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------
    //--------------------------new functions created----------------------------------




    //---------------------------------------------------------------
    //---------------------------------------------------------------

    public void reset_clicked(MenuItem item) {
        Toast.makeText(getApplicationContext(),"اختبار  حذف البيانات ",Toast.LENGTH_LONG).show();

    }

    public void load_clicked(MenuItem item) {
        Toast.makeText(getApplicationContext(),"اختبار التحميل  ",Toast.LENGTH_LONG).show();

    }

    public void save_clicked(MenuItem item) {
        Toast.makeText(getApplicationContext(),"اختبار  الحفظ ",Toast.LENGTH_LONG).show();

    }

    public void all_payed_clicked(MenuItem item) {
        Intent MyIntent=new Intent(this,add_Expenses.class);
        startActivity(MyIntent);
    }

    public void sett_sell_clicked(MenuItem item) {

        Intent MyIntent=new Intent(this,sell_select.class);
        startActivity(MyIntent);
    }

    public void sett_stock__clicked(MenuItem item) {

        Intent MyIntent=new Intent(this,stock_select.class);
        startActivity(MyIntent);
    }



    public void btn_stock_clicked(View view) {
        Intent MyIntent =new Intent(this, Tab3.class);
        startActivity(MyIntent);
    }

    public void btn_sell_clicked(View view) {

        Intent MyIntent =new Intent(this, Tab2.class);
        startActivity(MyIntent);
    }

    public void btn_gaint_clicked(View view) {

        Intent MyIntent =new Intent(this, Tab1.class);
        startActivity(MyIntent);
    }

    public void btn_payed_clicked(View view) {

        Intent MyIntent =new Intent(this, Tab4.class);
        startActivity(MyIntent);
    }




    //---------------------------------------------------------------


    //--------------------------ends all functions-------------------------------------
    //---------------------------------------------------------------------------------
    //---------------------------------------------------------------------------------

}
