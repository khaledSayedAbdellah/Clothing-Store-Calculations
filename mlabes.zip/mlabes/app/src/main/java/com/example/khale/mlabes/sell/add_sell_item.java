package com.example.khale.mlabes.sell;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.khale.mlabes.R;
import com.example.khale.mlabes.database.table.DatabaseHelper;
import com.example.khale.mlabes.database.table.OutgoingGoods;

import java.util.List;

public class add_sell_item extends AppCompatActivity {

    Spinner SpinnerItems;
    DatabaseHelper mydb;
    EditText price,number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_sell_item);

        price=findViewById(R.id.price_sell_item);
        number=findViewById(R.id.num_sell_item);

        SpinnerItems = findViewById(R.id.sell_spinner);

        mydb=new DatabaseHelper(this);

        loadSpinnerData();


    }

    private void loadSpinnerData() {
        // database handler
        DatabaseHelper db = new DatabaseHelper(getApplicationContext());
        SpinnerItems.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        // Spinner Drop down elements
        List<String> lables = db.getAllLabels();
        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, lables){
            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                if (position % 2 == 1) {
                    tv.setBackgroundColor(Color.parseColor("#5f98b5"));
                    SpinnerItems.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                    SpinnerItems.setTextDirection(View.TEXT_DIRECTION_LTR);
                } else{
                    tv.setBackgroundColor(Color.parseColor("#ffffff"));
                    SpinnerItems.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                    SpinnerItems.setTextDirection(View.TEXT_DIRECTION_LTR);
                }

                return view;
            }
        };
        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        SpinnerItems.setAdapter(dataAdapter);
    }

    public void add_sell_clicked(View view) {






        String[] spinner_texts = SpinnerItems.getSelectedItem().toString().split("-");

        String _name= spinner_texts[1].trim().replaceAll(" +", " ");
        String _price = price.getText().toString();
        String _code =spinner_texts[0].trim();
        String _number = number.getText().toString();

        long id=mydb.insert(OutgoingGoods.TABLE_NAME,new String[]
                        {OutgoingGoods.NAME,OutgoingGoods.PRICE, OutgoingGoods.CODE,OutgoingGoods.NUMBER},
                new String[]{_name,_price,_code,_number});

        if(id !=-1){
            Toast.makeText(getApplicationContext(),"تمت الاضافه",Toast.LENGTH_SHORT).show();

            price.setText("");
            number.setText("");
        }else {
            Toast.makeText(getApplicationContext(),"خطأ .. حاول مره اخري",Toast.LENGTH_SHORT).show();
        }

    }


}

